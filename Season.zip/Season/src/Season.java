public class Season {

    public int number(int num) {
        if (num == 12 || num == 1 || num == 2) {
            System.out.println("Winter");
            return 0;
        }
        //--------------------------------------
        if (num == 3 || num == 4 || num == 5) {
            System.out.println("spring");
            return 0;
        }
        //--------------------------------------

        if (num == 6 || num == 7  || num == 8) {
            System.out.println("summer");
            return 0;
        }
        //--------------------------------------

        if (num == 9 || num == 10 || num == 11) {
            System.out.println("autumn");
            return 0;
        }
        //--------------------------------------

        if (num >12 || num ==0){
            System.out.println("it is not true");
        }
        return num;
    }
}